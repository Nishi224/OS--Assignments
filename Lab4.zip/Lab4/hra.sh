echo Enter the basic salary
read sal
hra=` echo $sal\*20/100|bc`
echo The hra of the salary is $hra

