echo -n "Enter a number till which the sum is to be found"
read no
echo $no
n=`expr $no + 1 `
k=`expr $no \* $n `
ans=`expr $k / 2 `
echo $ans
 
