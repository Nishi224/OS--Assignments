echo Enter a string to be matched 
read str
echo Enter the file in which it is to be matched
read f
grep -q $str $f 
if [ $? -eq 0 ]
then
echo The string is there in the file
else
echo String not found
fi

