echo Enter the filename
read fn
cat $fn | tr -d '\n' | tr -s " " '\n' | wc -l
