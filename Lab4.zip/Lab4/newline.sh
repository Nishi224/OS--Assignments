echo Enter the filename
read filename
wc -l $filename 

