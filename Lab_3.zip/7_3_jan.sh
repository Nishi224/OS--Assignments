c=1
while [ $c = 1 ]
do
echo Enter a string like January
read str
str2='Jan'
str3='Janu'
str4='Janua'
str5='January'
str1='quit'
if [ $str = $str1 ]
then 
c=0

elif [ $str = $str2 ]
then  
echo January

elif [ $str = $str3 ]
then  
echo January

elif [ $str = $str4 ]
then  
echo January

elif [ $str = $str5 ]
then  
echo January

else
echo Enter another string 
fi
done 
