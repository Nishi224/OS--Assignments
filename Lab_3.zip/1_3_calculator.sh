#!/bin/bash

echo Enter the first variable
echo Enter the second variable

read n1
read n2

echo `expr $n1 + $n2`
echo `expr $n1 \* $n2`
echo `expr $n1 / $n2`
echo `expr $n1 % $n2`
echo `expr $n1 - $n2`



