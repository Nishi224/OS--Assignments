
while [ 1 ]
do
echo Enter a number
read n
if [ $n -lt 50 ]
then
echo `expr $n \* $n `
else 

echo Enter another number less than 50

fi
done
