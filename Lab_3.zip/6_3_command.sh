echo Enter the command to be exectued
read comm
$comm
