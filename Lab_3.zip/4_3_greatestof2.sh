#!/bin/bash
echo Enter two numbers
read n
read n1
if [ $n -gt $n1 ]
then 

echo $n is greater than $n1

elif [ $n -lt $n1 ] 
then 
echo $n is lessthan $n1

else 
echo Both are equal  
fi
 
