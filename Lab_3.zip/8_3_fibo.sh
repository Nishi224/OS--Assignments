n1=0
n2=1
cnt=2
echo Enter the number of numbers till you want the fibonacci series
read n3
echo $n1
echo $n2
while [ $cnt -le $n3 ]
do
echo `expr $n1 + $n2`
n4=`expr $n1 + $n2`
n1=$n2
n2=$n4

cnt=`expr $cnt + 1`
done	

