c=1
while [ $c = 1 ]
do
echo Enter the capital of Gujarat
read str
str1='Gandhinagar'
if [ $str = $str1 ]
then 
c=0
else
echo Enter the correct capital of Gujarat
fi
done
