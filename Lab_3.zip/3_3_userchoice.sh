#!/bin/bash

echo Enter the first variable
read n1
echo Enter the second variable
read n2
echo Enter the arithmetic operation you wish to perform
read n
case $n in 
+)echo `expr $n1 + $n2 `;;
*)echo `expr $n1 \* $n2 `;;
/)echo `expr $n1 / $n2 `;;
%)echo `expr $n1 % $n2 `;;
-)echo `expr $n1 - $n2 `;;
esac
