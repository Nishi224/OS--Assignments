#!/bin/bash

echo The addition is `expr $1 + $2`
echo The multiplication is `expr $1 \* $2`
echo The division is `expr $1 / $2`
echo The modulo is `expr $1 % $2`
echo The subtraction is `expr $1 - $2`

